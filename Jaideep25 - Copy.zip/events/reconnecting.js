const chalk = require('chalk');
module.exports = client => {
  console.log(chalk.bold("Reconnecting @ " + Date()));
}