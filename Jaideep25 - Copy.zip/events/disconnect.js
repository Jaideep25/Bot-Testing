const chalk = require('chalk');
module.exports = client => {
    console.log(chalk.bold("You have been disconnected @ " + Date()));
}