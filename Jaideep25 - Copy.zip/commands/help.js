function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min; //The maximum is inclusive and the minimum is inclusive
}

exports.run = function (client, message) {
    const Discord = require('discord.js');
    const config = client.config;
    var guild = message.guild;
    var select = getRandomIntInclusive(1, 3);
    const embed = new Discord.MessageEmbed()
        .setColor(select === 1 ? "#ccff00" : select === 2 ? "#0072bb" : select === 3 ? "#ff4f00" : "#ccff00")
        .setTitle("Fire Bot Help\n")
        .addField('Prefix', `\`${config.prefix}\``)
        .addField('Example:', `\`${config.prefix}ping\``)
        .addField('Commands:', `Do \`${config.prefix}commands\` to see a full list of commands.`)
        .addField(`Setup`, `${config.name} requires a **modlog text channel**, a **debatelog text channel** and a **Mute role called "Mute"**. For automatic setup please use \`${config.prefix}setup\`. Otherwise please create these roles and channels.`)
        // .addField('Checklist:', `Please run the command \`${config.prefix}checklist\` to check if fire bot has all the required permissions to run.`)
        .addField(`Opt-outs`, `User the \`${config.prefix}optout\` to opt-out of any command including dm & userinfo.`)
        .addField('Bot Invite Link', `Use \`${config.prefix}invite\` for the bot's invite link, or click [here](https://discord.com/oauth2/authorize?client_id=815249844985266206&scope=bot&permissions=2146958591)`)
        .setFooter(`Made by ${config.ownerTag}`)
        .setTimestamp()

    message.channel.send({ embed: embed })
    client.logger.log('info', `help command used by ${message.author.username} Time: ${Date()} Guild: ${message.guild}`)
}